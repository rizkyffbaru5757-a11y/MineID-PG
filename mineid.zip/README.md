# MineID Snippets — Milestone 1

Native Android Kotlin app for local code snippets.

Included: Jetpack Compose + Material 3, Room offline database, add/delete snippets, search title/language/code, dark MineID gold-accent UI, GitHub Actions debug APK workflow.

## Build APK with GitHub Actions
1. Upload the contents of this folder to the root of a GitHub repository. Keep the `.github` folder.
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Run **Android Debug APK** with **Run workflow**, or push a commit to `main`/`master`.
4. Open the successful run and download artifact `MineIDSnippets-debug-apk`.

This ZIP contains source and build workflow, not a prebuilt APK.
