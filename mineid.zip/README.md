# MineID Snippet

Native Android code-snippet manager (Kotlin, Jetpack Compose; Room planned). Offline-first, no backend.

**Status:** Milestone 1 (project foundation), under verification. No features yet.

## Toolchain (see "Verification status" below)
| Tool | Version | Source of the constraint |
|---|---|---|
| Android Gradle Plugin | 9.2.1 | Android AGP 9.2 release notes |
| Gradle | 9.4.1 | Minimum and default for AGP 9.2 |
| JDK | 17 or newer | AGP minimum is 17 (CI uses 17) |
| Kotlin and Compose compiler plugin | 2.3.10 (same version) | KGP >= 2.2.10 required by AGP 9 |
| Compose BOM | 2026.09.00 | Listed as latest in Android Compose docs |
| activity-compose | 1.13.0 | Used in the same docs |
| compileSdk / targetSdk / minSdk | 37 / 36 / 26 | Compose 1.12+ needs compileSdk 37 and AGP 9; AGP 9.2 supports up to API 37 |

AGP 9 has built-in Kotlin, so the `org.jetbrains.kotlin.android` plugin is not applied. The Kotlin Gradle
plugin is pinned in the root `build.gradle.kts` (same number as `kotlin` in `gradle/libs.versions.toml`).

## Gradle wrapper (not committed yet)
`gradle-wrapper.jar` is binary and could not be generated where M1 was written (no Gradle, no network).
Generate it one of these ways, then commit `gradlew`, `gradlew.bat` and `gradle/wrapper/`:

1. Locally, with Gradle 9.4.1 installed:

       gradle wrapper --gradle-version 9.4.1 --distribution-type bin

   Add `--gradle-distribution-sha256-sum <hash>` using the value from
   https://services.gradle.org/distributions/gradle-9.4.1-bin.zip.sha256
2. On GitHub: Actions, "Generate Gradle Wrapper", Run workflow, then download the `gradle-wrapper-files`
   artifact and copy its contents into the repository root.
3. Android Studio can also create the wrapper when it opens a Gradle project.

On Linux/macOS make the script executable before committing: `git update-index --chmod=+x gradlew`.
The CI workflow uses `./gradlew` automatically once it exists.

## Build
    ./gradlew assembleDebug        # after the wrapper exists
    gradle assembleDebug           # with Gradle 9.4.1 on PATH and ANDROID_HOME set

Output: `app/build/outputs/apk/debug/app-debug.apk`. Debug builds need no signing secrets.
Requires Android SDK platform `android-37.0` and build-tools `36.0.0`.

## CI
`.github/workflows/android-debug.yml` builds the debug APK and uploads `app-debug.apk` as the
`mineid-snippet-debug-apk` artifact (Actions tab, open a run, Artifacts section). A failed build fails the run.

## Verification status
No Gradle build has been run for this project yet. Dependency compatibility is based on documentation only.
