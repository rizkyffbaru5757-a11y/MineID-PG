// Top-level build file. Plugin versions live in gradle/libs.versions.toml.

// AGP 9 ships built-in Kotlin with a runtime dependency on KGP. The official way to use a
// newer KGP is to declare it on the buildscript classpath. This keeps the Kotlin Gradle plugin
// aligned with the Compose compiler plugin (same version as `kotlin` in libs.versions.toml).
buildscript {
    repositories {
        mavenCentral()
    }
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.10")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
