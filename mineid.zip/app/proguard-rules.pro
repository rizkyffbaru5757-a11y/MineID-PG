# Project-specific R8/ProGuard rules. Intentionally empty in M1.
