package com.mineid.snippets

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.mineid.snippets.data.Snippet
import com.mineid.snippets.data.SnippetDatabase
import kotlinx.coroutines.launch

private val Ink = Color(0xFF0B0C0E)
private val Panel = Color(0xFF15171A)
private val Gold = Color(0xFFF0C75E)
private val Muted = Color(0xFF9298A1)
private val MainText = Color(0xFFF2F3F5)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val dao = SnippetDatabase.get(this).snippetDao()
  setContent {
   val snippets by dao.observeAll().collectAsState(initial = emptyList())
   var query by remember { mutableStateOf("") }
   var showEditor by remember { mutableStateOf(false) }
   var title by remember { mutableStateOf("") }
   var language by remember { mutableStateOf("Kotlin") }
   var code by remember { mutableStateOf("") }
   var pendingDelete by remember { mutableStateOf<Snippet?>(null) }
   MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel, onBackground = MainText, onSurface = MainText)) {
    Surface(Modifier.fillMaxSize(), color = Ink) {
     Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
      Spacer(Modifier.height(28.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
       Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Terminal, null, tint = Ink) }
       Spacer(Modifier.width(12.dp))
       Column(Modifier.weight(1f)) { Text("MineID", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("SNIPPETS / LOCAL LIBRARY", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp) }
       Text("${snippets.size} ITEMS", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      }
      Spacer(Modifier.height(28.dp))
      Text("Your code,\nkept close.", color = MainText, fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(8.dp))
      Text("Simpan dan temukan potongan kode tanpa perlu koneksi internet.", color = Muted, fontSize = 13.sp)
      Spacer(Modifier.height(18.dp))
      if (showEditor) {
       Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
         Text("NEW SNIPPET", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
         Spacer(Modifier.height(12.dp))
         OutlinedTextField(title, { title = it }, label = { Text("Judul snippet") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
         Spacer(Modifier.height(8.dp))
         OutlinedTextField(language, { language = it }, label = { Text("Bahasa / teknologi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
         Spacer(Modifier.height(8.dp))
         OutlinedTextField(code, { code = it }, label = { Text("Kode") }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), minLines = 4)
         Spacer(Modifier.height(12.dp))
         Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedButton(onClick = { showEditor = false }, modifier = Modifier.weight(1f)) { Text("Batal") }
          Button(onClick = { if (title.isNotBlank() && code.isNotBlank()) { lifecycleScope.launch { dao.insert(Snippet(title = title.trim(), language = language.trim().ifBlank { "Text" }, code = code)) }; title = ""; language = "Kotlin"; code = ""; showEditor = false } }, enabled = title.isNotBlank() && code.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Simpan") }
         }
        }
       }
       Spacer(Modifier.height(14.dp))
      }
      OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Cari judul, bahasa, atau kode…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
       Text("SNIPPET LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
       Spacer(Modifier.weight(1f))
       TextButton(onClick = { showEditor = !showEditor }) { Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text(if (showEditor) "Tutup" else "Tambah") }
      }
      val filtered = snippets.filter { query.isBlank() || it.title.contains(query.trim(), true) || it.language.contains(query.trim(), true) || it.code.contains(query.trim(), true) }
      if (filtered.isEmpty()) {
       Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
         Icon(Icons.Default.Code, null, tint = Muted, modifier = Modifier.size(34.dp)); Spacer(Modifier.height(12.dp))
         Text(if (query.isBlank()) "Belum ada snippet" else "Snippet tidak ditemukan", color = MainText, fontWeight = FontWeight.SemiBold)
         Spacer(Modifier.height(4.dp)); Text(if (query.isBlank()) "Tekan Tambah untuk menyimpan kode pertama." else "Coba kata kunci lain.", color = Muted, fontSize = 12.sp)
        }
       }
      } else {
       LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        items(filtered, key = { it.id }) { snippet ->
         Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
          Column(Modifier.fillMaxWidth().padding(15.dp)) {
           Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).background(Color(0xFF28251A), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Code, null, tint = Gold, modifier = Modifier.size(18.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(snippet.title, color = MainText, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(snippet.language.uppercase(), color = Gold, fontSize = 10.sp, letterSpacing = 1.sp) }
            IconButton(onClick = { pendingDelete = snippet }) { Icon(Icons.Default.DeleteOutline, "Hapus snippet", tint = Muted) }
           }
           Spacer(Modifier.height(8.dp)); Text(snippet.code.lines().take(3).joinToString("\n"), color = Color(0xFFB8C0CA), fontSize = 12.sp, lineHeight = 18.sp, maxLines = 3)
          }
         }
        }
       }
      }
     }
    }
    pendingDelete?.let { target -> AlertDialog(onDismissRequest = { pendingDelete = null }, title = { Text("Hapus snippet?") }, text = { Text("‘${target.title}’ akan dihapus dari perangkat ini.") }, confirmButton = { TextButton(onClick = { lifecycleScope.launch { dao.delete(target) }; pendingDelete = null }) { Text("Hapus", color = Color(0xFFE57373)) } }, dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }) }
   }
  }
 }
}
