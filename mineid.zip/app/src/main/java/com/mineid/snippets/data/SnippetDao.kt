package com.mineid.snippets.data
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
@Dao interface SnippetDao {
 @Query("SELECT * FROM snippets ORDER BY createdAt DESC") fun observeAll(): Flow<List<Snippet>>
 @Insert suspend fun insert(snippet: Snippet)
 @Delete suspend fun delete(snippet: Snippet)
}
