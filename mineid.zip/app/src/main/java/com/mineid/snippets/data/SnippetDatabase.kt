package com.mineid.snippets.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities = [Snippet::class], version = 1, exportSchema = false)
abstract class SnippetDatabase : RoomDatabase() {
 abstract fun snippetDao(): SnippetDao
 companion object {
  @Volatile private var instance: SnippetDatabase? = null
  fun get(context: Context): SnippetDatabase = instance ?: synchronized(this) { instance ?: Room.databaseBuilder(context.applicationContext, SnippetDatabase::class.java, "mineid_snippets.db").build().also { instance = it } }
 }
}
