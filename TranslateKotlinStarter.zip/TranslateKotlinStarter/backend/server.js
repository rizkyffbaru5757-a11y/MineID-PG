import 'dotenv/config';
import Fastify from 'fastify';
import rateLimit from '@fastify/rate-limit';

const app = Fastify({ logger: true, bodyLimit: 32 * 1024 });
const API_KEY = process.env.GOOGLE_TRANSLATE_API_KEY;

await app.register(rateLimit, {
  max: 30,
  timeWindow: '1 minute'
});

app.get('/health', async () => ({ ok: true }));

app.post('/api/translate', async (request, reply) => {
  if (!API_KEY) {
    return reply.code(500).send({ error: 'Backend belum dikonfigurasi: API key belum tersedia.' });
  }

  const body = request.body ?? {};
  const text = typeof body.text === 'string' ? body.text.trim() : '';
  const target = typeof body.target === 'string' ? body.target.trim() : '';
  const source = typeof body.source === 'string' ? body.source.trim() : '';

  if (!text) return reply.code(400).send({ error: 'Teks tidak boleh kosong.' });
  if (text.length > 5000) return reply.code(400).send({ error: 'Maksimal 5000 karakter per permintaan.' });
  if (!/^[a-zA-Z-]{2,10}$/.test(target)) return reply.code(400).send({ error: 'Kode bahasa tujuan tidak valid.' });
  if (source && !/^[a-zA-Z-]{2,10}$/.test(source)) return reply.code(400).send({ error: 'Kode bahasa sumber tidak valid.' });

  const params = new URLSearchParams({
    q: text,
    target,
    format: 'text',
    key: API_KEY
  });
  if (source) params.set('source', source);

  try {
    const googleResponse = await fetch(
      `https://translation.googleapis.com/language/translate/v2?${params.toString()}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }
    );
    const data = await googleResponse.json();

    if (!googleResponse.ok) {
      request.log.warn({ statusCode: googleResponse.status }, 'Google Translation API request failed');
      return reply.code(502).send({
        error: data?.error?.message || 'Google Translation API gagal memproses permintaan.'
      });
    }

    const translation = data?.data?.translations?.[0];
    if (!translation?.translatedText) {
      return reply.code(502).send({ error: 'Google tidak mengembalikan hasil terjemahan.' });
    }

    return {
      translatedText: translation.translatedText,
      detectedSourceLanguage: translation.detectedSourceLanguage ?? source ?? null
    };
  } catch (error) {
    request.log.error(error);
    return reply.code(502).send({ error: 'Tidak dapat menghubungi Google Translation API.' });
  }
});

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';
try {
  await app.listen({ port, host });
} catch (err) {
  app.log.error(err);
  process.exit(1);
}
