package com.mineid.translate.data

import retrofit2.http.Body
import retrofit2.http.POST

data class TranslateRequest(
    val text: String,
    val source: String?,
    val target: String
)

data class TranslateResponse(
    val translatedText: String,
    val detectedSourceLanguage: String?
)

interface TranslateApi {
    @POST("api/translate")
    suspend fun translate(@Body request: TranslateRequest): TranslateResponse
}

object NetworkModule {
    // Emulator: 10.0.2.2 points to the host computer.
    // Replace with your own HTTPS backend URL before deploying to real devices.
    private const val BASE_URL = "http://10.0.2.2:3000/"

    val api: TranslateApi by lazy {
        retrofit2.Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
            .build()
            .create(TranslateApi::class.java)
    }
}
