package com.mineid.translate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mineid.translate.data.TranslateApi
import com.mineid.translate.data.TranslateRequest
import com.mineid.translate.data.NetworkModule
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { TranslateScreen() } }
    }
}

private data class Language(val label: String, val code: String)
private val languages = listOf(
    Language("Deteksi otomatis", "auto"),
    Language("Indonesia", "id"),
    Language("Inggris", "en"),
    Language("Jepang", "ja"),
    Language("Korea", "ko"),
    Language("Mandarin", "zh"),
    Language("Prancis", "fr"),
    Language("Jerman", "de"),
    Language("Spanyol", "es"),
    Language("Arab", "ar"),
    Language("Portugis", "pt"),
    Language("Rusia", "ru"),
    Language("Thailand", "th"),
    Language("Vietnam", "vi"),
    Language("Italia", "it"),
    Language("Turki", "tr")
)

class TranslateViewModel : ViewModel() {
    var input by mutableStateOf("")
    var output by mutableStateOf("")
    var source by mutableStateOf(languages[0])
    var target by mutableStateOf(languages[1])
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun swap() {
        if (source.code == "auto") {
            error = "Pilih bahasa sumber terlebih dahulu sebelum menukar."
            return
        }
        val old = source
        source = target
        target = old
        val oldText = input
        input = output
        output = oldText
        error = null
    }

    fun translate() {
        if (input.isBlank()) {
            error = "Masukkan teks yang ingin diterjemahkan."
            return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val response = NetworkModule.api.translate(
                    TranslateRequest(
                        text = input.trim(),
                        source = source.code.takeUnless { it == "auto" },
                        target = target.code
                    )
                )
                output = response.translatedText
            } catch (e: Exception) {
                error = when {
                    e.message?.contains("Unable to resolve host", true) == true ->
                        "Tidak dapat terhubung. Periksa koneksi dan alamat backend."
                    else -> e.message ?: "Terjadi kesalahan saat menerjemahkan."
                }
            } finally {
                loading = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TranslateScreen(vm: TranslateViewModel = viewModel()) {
    val clipboard = LocalClipboardManager.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Translate", fontWeight = FontWeight.Bold)
                        Text("Terjemahkan teks dengan mudah", style = MaterialTheme.typography.labelMedium)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LanguageDropdown("Dari", vm.source, languages) { vm.source = it }
                        IconButton(onClick = vm::swap, modifier = Modifier.padding(top = 22.dp)) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Tukar bahasa")
                        }
                        LanguageDropdown("Ke", vm.target, languages.filter { it.code != "auto" }) { vm.target = it }
                    }
                    OutlinedTextField(
                        value = vm.input,
                        onValueChange = { vm.input = it; vm.error = null },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                        label = { Text("Teks yang akan diterjemahkan") },
                        placeholder = { Text("Ketik atau tempel teks di sini...") },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        supportingText = { Text("${vm.input.length} karakter") },
                        trailingIcon = {
                            if (vm.input.isNotEmpty()) TextButton(onClick = { vm.input = ""; vm.output = "" }) {
                                Text("Hapus")
                            }
                        }
                    )
                    Button(
                        onClick = vm::translate,
                        enabled = !vm.loading && vm.input.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        if (vm.loading) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Menerjemahkan...")
                        } else {
                            Icon(Icons.Default.Translate, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Terjemahkan")
                        }
                    }
                }
            }

            if (vm.error != null) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(
                        vm.error.orEmpty(),
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Hasil terjemahan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        IconButton(
                            onClick = { if (vm.output.isNotBlank()) clipboard.setText(AnnotatedString(vm.output)) },
                            enabled = vm.output.isNotBlank()
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Salin hasil")
                        }
                    }
                    Text(
                        text = vm.output.ifBlank { "Hasil terjemahan akan muncul di sini." },
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (vm.output.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Text(
                "Terjemahan menggunakan Google Cloud Translation API.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RowScope.LanguageDropdown(
    title: String,
    selected: Language,
    options: List<Language>,
    onSelected: (Language) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.widthIn(min = 0.dp).weight(1f)) {
        Text(title, style = MaterialTheme.typography.labelMedium)
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(
                value = selected.label,
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { language ->
                    DropdownMenuItem(
                        text = { Text(language.label) },
                        onClick = { onSelected(language); expanded = false }
                    )
                }
            }
        }
    }
}
