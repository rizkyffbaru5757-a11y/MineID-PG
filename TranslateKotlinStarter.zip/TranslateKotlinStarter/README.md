# Translate Kotlin Starter

A minimal Android translation app using Kotlin, Jetpack Compose, Material 3, Retrofit, and a small Fastify backend.
The Google Cloud Translation API key stays on the backend, not inside the APK.

## Requirements
- Android Studio with Android SDK installed
- JDK 17
- Node.js 20+
- Google Cloud project with Cloud Translation API enabled and billing configured

## 1. Configure Google Cloud
1. Open Google Cloud Console and select/create a project.
2. Enable **Cloud Translation API**.
3. Create an API key and restrict it to the Cloud Translation API.
4. Do not put the key into Android source code.

Official docs: https://cloud.google.com/translate/docs/setup

## 2. Start backend
```bash
cd backend
cp .env.example .env
# Edit .env and set GOOGLE_TRANSLATE_API_KEY
npm install
npm start
```
Backend listens on port 3000 by default. Test:
```bash
curl http://localhost:3000/health
```

For a real Android phone, the backend must be hosted on a server reachable from the phone over HTTPS.
For local Android Emulator only, `http://10.0.2.2:3000/` points to your computer's localhost.
The app currently uses that emulator address. Change `BASE_URL` in `app/src/main/java/com/mineid/translate/data/TranslateApi.kt` for your own HTTPS backend.

## 3. Open Android app
1. Open this folder in Android Studio (or open the `app` folder).
2. Let Gradle sync.
3. Run on an emulator/device.
4. Set `BASE_URL` as described above before using it on a physical phone.

## Included
- Source language and target language selectors
- Auto-detect source language
- Swap languages
- Translate button and loading state
- Copy result
- Clear input
- Basic error handling
- Backend-side API key storage

## Notes
- Google Cloud Translation is a paid service after any applicable current credits/allowances. Review current pricing and quotas before use.
- This is a starter project; production deployment should add HTTPS, rate limiting, request size limits, monitoring, and abuse protection.
